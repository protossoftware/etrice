The FreeRTOS eTrice runtime environment requires a running FreeRTOS for your specific target.
Once you have your FreeRTOS running, it is very simple to adapt to your specific target.
 
Within this directory you find some example implementations for dedicated targets.
 
Please copy one of those example files into your project and compile it in your context.
If necessary adapt the file to your needs.

