/*******************************************************************************
 * Copyright (c) 2011 protos software gmbh (http://www.protos.de).
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * CONTRIBUTORS:
 * 		Thomas Schuetz (initial contribution), Thomas Jung
 *
 *******************************************************************************/

#ifndef _ETDATATYPES_H_
#define _ETDATATYPES_H_

/*
 * typedefs for platform specific datatypes
 * FreeRTOS on a 32Bit version
 */

#include "etStdDatatypes.h"

#include <stdio.h>
#include <FreeRTOS.h>
#include <task.h>
#include <timers.h>
#include <semphr.h>

/*--- Data types for room.basic.types */

typedef unsigned long long uint64;

typedef long long int64;

typedef float float32;
/* typedef double float64; */ /* not available on this platform */

/*-----------------------------------------------------------*/


/*--- Data types for runtime */

#define ALIGNMENT		4	/* power of 2 and >= sizeof(int) ! */

typedef float32 etFloat32;

typedef FILE* etFileHandle;

/* types for osal */
typedef xSemaphoreHandle etOSMutexData;
typedef xSemaphoreHandle etOSSemaData;

typedef xTaskHandle etOSThreadData;
typedef uint16 etOSThreadId;

typedef xTimerHandle etOSTimerData;
typedef uint16 etOSTimerId;

/*-----------------------------------------------------------*/

#endif /* _DATATYPES_H_ */
