/*
 * etPlatform.h
 *
 *  Created on: 23.06.2012
 *      Author: junggtho
 */

#ifndef ETPLATFORM_H_
#define ETPLATFORM_H_


#endif /* ETPLATFORM_H_ */
