/*******************************************************************************
 * Copyright (c) 2011 protos software gmbh (http://www.protos.de).
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * CONTRIBUTORS:
 * 		Thomas Schuetz (initial contribution), Thomas Jung
 *
 *******************************************************************************/

#ifndef _ETDATATYPES_H_
#define _ETDATATYPES_H_

/*
 * typedefs for platform specific datatypes
 * Version for 32 Bit Controllers like ARM Cortex M
 */

#include "etStdDatatypes.h"

#include <stdio.h>


/*--- Data types for room.basic.types */

typedef float float32;
/* typedef double float64; */ /* not available on this platform */

/*-----------------------------------------------------------*/


/*--- Data types for runtime */

#define ALIGNMENT		4	/* power of 2 and >= sizeof(int) ! */

typedef FILE* etFileHandle;

/* types for osal */
typedef uint32 etOSMutexData;
typedef uint32 etOSSemaData;
typedef uint32 etOSThreadData;
typedef uint32 etOSThreadId;
typedef uint32 etOSTimerData;
typedef uint32 etOSTimerId;

/*-----------------------------------------------------------*/

#endif /* _DATATYPES_H_ */
