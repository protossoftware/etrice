/*
 * etPlatform.h
 *
 *  Created on: 23.06.2012
 *      Author: junggtho
 */

#ifndef ETPLATFORM_H_
#define ETPLATFORM_H_

void initHw(void);

#endif /* ETPLATFORM_H_ */
