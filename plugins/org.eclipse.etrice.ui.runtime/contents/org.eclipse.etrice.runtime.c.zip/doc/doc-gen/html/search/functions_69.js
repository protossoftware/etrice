var searchData=
[
  ['initclocksystem',['initClockSystem',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#a0153c6ea5791944e0506740dff94f176',1,'etPlatform.c']]],
  ['inithw',['initHw',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#a32a4e2bf88f95d0a217b766a58cc5af6',1,'etPlatform.c']]],
  ['initio',['initIO',['../_s_t___m_s_p430___f5438___c_c_s5___e_x_p430_f5438_2et_platform_8c.html#ac3c73735519c0fbd83b55f44c3536b96',1,'etPlatform.c']]],
  ['initmotor',['initMotor',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#a95a7912f695301a97a3a691a4918fdeb',1,'etPlatform.c']]],
  ['initportsforelevator',['initPortsForElevator',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#aa2367e92293ca4c840b6686ffba353cc',1,'etPlatform.c']]],
  ['istimegreaterthanactualtime',['isTimeGreaterThanActualTime',['../_s_t___m_s_p430___f5438___c_c_s5___e_x_p430_f5438_2et_timer_8c.html#adf97ed3053e5fedb731f10d20da40354',1,'isTimeGreaterThanActualTime(const etTargetTime_t *t):&#160;etTimer.c'],['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_timer_8c.html#adf97ed3053e5fedb731f10d20da40354',1,'isTimeGreaterThanActualTime(const etTargetTime_t *t):&#160;etTimer.c']]]
];
