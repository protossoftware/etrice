var searchData=
[
  ['invalid_5fsocket',['INVALID_SOCKET',['../_m_t___p_o_s_i_x___g_e_n_e_r_i_c___g_c_c_2et_tcp_sockets_8c.html#a26769957ec1a2beaf223f33b66ee64ab',1,'etTcpSockets.c']]]
];
