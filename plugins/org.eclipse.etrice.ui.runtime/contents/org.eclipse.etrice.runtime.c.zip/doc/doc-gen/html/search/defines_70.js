var searchData=
[
  ['print_5fdebug',['PRINT_DEBUG',['../_m_t___p_o_s_i_x___g_e_n_e_r_i_c___g_c_c_2et_tcp_sockets_8c.html#aa436e272dda4ed44aae67d5e71124a35',1,'PRINT_DEBUG():&#160;etTcpSockets.c'],['../_m_t___w_i_n___min_g_w_2et_tcp_sockets_8c.html#aa436e272dda4ed44aae67d5e71124a35',1,'PRINT_DEBUG():&#160;etTcpSockets.c']]],
  ['prio',['PRIO',['../_m_t___p_o_s_i_x___g_e_n_e_r_i_c___g_c_c_2et_tcp_sockets_8c.html#aef8f07401842218539bdd0f689991002',1,'PRIO():&#160;etTcpSockets.c'],['../_m_t___w_i_n___min_g_w_2et_tcp_sockets_8c.html#aef8f07401842218539bdd0f689991002',1,'PRIO():&#160;etTcpSockets.c']]]
];
