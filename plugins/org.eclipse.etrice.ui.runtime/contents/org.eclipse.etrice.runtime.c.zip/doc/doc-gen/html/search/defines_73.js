var searchData=
[
  ['stack_5fsize',['STACK_SIZE',['../_m_t___p_o_s_i_x___g_e_n_e_r_i_c___g_c_c_2et_tcp_sockets_8c.html#a6423a880df59733d2d9b509c7718d3a9',1,'STACK_SIZE():&#160;etTcpSockets.c'],['../_m_t___w_i_n___min_g_w_2et_tcp_sockets_8c.html#a6423a880df59733d2d9b509c7718d3a9',1,'STACK_SIZE():&#160;etTcpSockets.c']]]
];
