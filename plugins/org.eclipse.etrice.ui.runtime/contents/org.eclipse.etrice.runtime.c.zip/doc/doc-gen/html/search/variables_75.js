var searchData=
[
  ['userdata',['userData',['../structet_socket_server_data.html#ad85d8e16915b2f157bbc0a5272a14601',1,'etSocketServerData::userData()'],['../structet_socket_connection_data.html#a00a2592f8aff25d982aa7acf5752a25d',1,'etSocketConnectionData::userData()']]]
];
