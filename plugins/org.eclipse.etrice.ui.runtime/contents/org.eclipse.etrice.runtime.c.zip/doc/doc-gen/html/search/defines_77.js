var searchData=
[
  ['winver',['WINVER',['../_m_t___w_i_n___min_g_w_2et_datatypes_8h.html#a966cd377b9f3fdeb1432460c33352af1',1,'etDatatypes.h']]]
];
