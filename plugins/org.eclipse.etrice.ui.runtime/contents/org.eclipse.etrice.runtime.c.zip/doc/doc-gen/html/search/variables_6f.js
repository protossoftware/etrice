var searchData=
[
  ['objsize',['objsize',['../structet_free_list_info.html#a8224cf0c86d4dd623106185e237df4ed',1,'etFreeListInfo']]],
  ['osdata',['osData',['../structet_mutex.html#ae251696554e14c1f7b7d6ee94176fc73',1,'etMutex::osData()'],['../structet_sema.html#aea379a85e3a7fe757e8094c8a6b828e2',1,'etSema::osData()'],['../structet_thread.html#a0765ba81ce60694176300a92125c0ac4',1,'etThread::osData()']]],
  ['osid',['osId',['../structet_thread.html#a487b79436c239c2929579456a900cee5',1,'etThread']]],
  ['ostimerdata',['osTimerData',['../structet_timer.html#a2f183a3b5e7f3fe064f16ded285355a3',1,'etTimer']]]
];
