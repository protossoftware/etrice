var searchData=
[
  ['updatefloorlatch',['updateFloorLatch',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#a0b6d8d0feff8c402391cc7965e17ad69',1,'etPlatform.c']]],
  ['updatemotorlatch',['updateMotorLatch',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#a7d42e7c5a68ddb42fe6fe07d00e54dad',1,'etPlatform.c']]]
];
