var searchData=
[
  ['prvsetuphardware',['prvSetupHardware',['../_s_t___m_s_p430___f5438___c_c_s5___e_x_p430_f5438_2et_platform_8c.html#a464ac1a014942c092b752b720c4ff294',1,'etPlatform.c']]]
];
