var searchData=
[
  ['setdata',['setData',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#a5699235876a59e7c0a801c04bc0b306f',1,'etPlatform.c']]],
  ['setledpin',['setLedPin',['../_s_t___m_s_p430___f5438___c_c_s5___e_x_p430_f5438_2et_platform_8c.html#a651445d0396813e8ba491a7f234ca1d7',1,'etPlatform.c']]],
  ['shiftmotordown',['shiftMotorDown',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#acd8d488f97fb97fb270a2ff509ea6e38',1,'shiftMotorDown(void):&#160;etPlatform.c'],['../et_platform_8h.html#acd8d488f97fb97fb270a2ff509ea6e38',1,'shiftMotorDown(void):&#160;etPlatform.c']]],
  ['shiftmotorup',['shiftMotorUp',['../_s_t___m_s_p430___f5438___c_c_s5___h_w_elevator_2et_platform_8c.html#ab66b43178ac77a4b24df356c4061c444',1,'shiftMotorUp(void):&#160;etPlatform.c'],['../et_platform_8h.html#ab66b43178ac77a4b24df356c4061c444',1,'shiftMotorUp(void):&#160;etPlatform.c']]]
];
