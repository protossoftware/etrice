var searchData=
[
  ['local_5fhost',['LOCAL_HOST',['../_m_t___p_o_s_i_x___g_e_n_e_r_i_c___g_c_c_2et_tcp_sockets_8c.html#aacebc74ef9a786231060d3a8d8b56d24',1,'LOCAL_HOST():&#160;etTcpSockets.c'],['../_m_t___w_i_n___min_g_w_2et_tcp_sockets_8c.html#aacebc74ef9a786231060d3a8d8b56d24',1,'LOCAL_HOST():&#160;etTcpSockets.c']]]
];
