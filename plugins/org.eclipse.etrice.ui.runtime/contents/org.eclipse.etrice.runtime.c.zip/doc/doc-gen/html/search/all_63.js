var searchData=
[
  ['cabine_5fbutton_5fid',['CABINE_BUTTON_ID',['../et_platform_8h.html#a2b0297bb3d5133e8ffd93659c45222e3',1,'etPlatform.h']]],
  ['cabine_5fdoor_5fbutton_5fid',['CABINE_DOOR_BUTTON_ID',['../et_platform_8h.html#adf45308f67e258ee99353537f4734d85',1,'etPlatform.h']]],
  ['cabine_5fswitch_5fled',['CABINE_SWITCH_LED',['../et_platform_8h.html#a9f31bfc184e9c1042cfaa248e27955f0',1,'etPlatform.h']]],
  ['channel',['channel',['../structet_socket_connection_data_impl.html#a0ca83ff49ffa890ef439fa8a694bc621',1,'etSocketConnectionDataImpl']]],
  ['charptr',['charPtr',['../_m_t___p_o_s_i_x___g_e_n_e_r_i_c___g_c_c_2et_datatypes_8h.html#a9bc8fec48e1fb48f38d5ffdd3a472504',1,'charPtr():&#160;etDatatypes.h'],['../_m_t___w_i_n___min_g_w_2et_datatypes_8h.html#a9bc8fec48e1fb48f38d5ffdd3a472504',1,'charPtr():&#160;etDatatypes.h']]],
  ['connections',['connections',['../structet_socket_server_data_impl.html#a6ede4e96fe315aaab4456b6662375df1',1,'etSocketServerDataImpl']]],
  ['current',['current',['../structet_free_list_memory.html#a5911420e8d786fea15e5d7a2b4419176',1,'etFreeListMemory']]],
  ['currentindex',['currentIndex',['../struct_order_info.html#a1723a88c619fede0f78e0b1bab6979d5',1,'OrderInfo']]]
];
