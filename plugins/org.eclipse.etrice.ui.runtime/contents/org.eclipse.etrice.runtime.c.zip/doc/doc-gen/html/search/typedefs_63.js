var searchData=
[
  ['charptr',['charPtr',['../_m_t___p_o_s_i_x___g_e_n_e_r_i_c___g_c_c_2et_datatypes_8h.html#a9bc8fec48e1fb48f38d5ffdd3a472504',1,'charPtr():&#160;etDatatypes.h'],['../_m_t___w_i_n___min_g_w_2et_datatypes_8h.html#a9bc8fec48e1fb48f38d5ffdd3a472504',1,'charPtr():&#160;etDatatypes.h']]]
];
