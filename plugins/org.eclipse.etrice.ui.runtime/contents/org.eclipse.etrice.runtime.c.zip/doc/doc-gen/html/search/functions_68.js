var searchData=
[
  ['handlesystemevent',['handleSystemEvent',['../et_actor_8c.html#adb03e2d7d8293e70294de2510f0fe2dc',1,'handleSystemEvent(InterfaceItemBase *ifitem, int evt, void *generic_data):&#160;etActor.c'],['../et_actor_8h.html#adb03e2d7d8293e70294de2510f0fe2dc',1,'handleSystemEvent(InterfaceItemBase *ifitem, int evt, void *generic_data):&#160;etActor.c']]]
];
