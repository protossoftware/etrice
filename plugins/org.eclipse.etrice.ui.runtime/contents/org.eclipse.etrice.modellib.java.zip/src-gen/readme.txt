This directory is an eTrice code generation target.
It will be erased every time the generator is executed.

DO NOT PLACE OTHER FILES HERE!
