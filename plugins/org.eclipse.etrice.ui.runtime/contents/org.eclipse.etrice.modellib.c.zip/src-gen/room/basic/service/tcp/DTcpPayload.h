#ifndef _ROOM_BASIC_SERVICE_TCP_DTCPPAYLOAD_H_
#define _ROOM_BASIC_SERVICE_TCP_DTCPPAYLOAD_H_

#include "common/etDatatypesCpp.hpp"


using namespace etRuntime; // TODO JH remove


class DTcpPayload {

public:

	/*--------------------- attributes ---------------------*/
	 int32 connectionId;
	 int32 length;
	 StaticArray<int8, 32> data;

	/* --------------------- attribute setters and getters */
	void setConnectionId(int32 connectionId) {
		 this->connectionId = connectionId;
	}
	int32 getConnectionId() const {
		return this->connectionId;
	}
	void setLength(int32 length) {
		 this->length = length;
	}
	int32 getLength() const {
		return this->length;
	}
	void setData(StaticArray<int8, 32>& data) {
		 this->data = data;
	}
	StaticArray<int8, 32>& getData() {
		return this->data;
	}

	/*--------------------- operations ---------------------*/
	 int32 getMaxLength();
	 void setAsString(charPtr value);
	 void setData(int8* value, int32 size);
	 charPtr getAsString();

	// default constructor, copy constructor and assignment operator
	DTcpPayload();
	DTcpPayload(const DTcpPayload& rhs);
	// constructor using fields
	DTcpPayload(const int32 connectionId, const int32 length, const StaticArray<int8, 32>& data);

	DTcpPayload& operator=(const DTcpPayload& rhs);

};


#endif /* _ROOM_BASIC_SERVICE_TCP_DTCPPAYLOAD_H_ */

