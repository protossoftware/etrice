#ifndef _ROOM_BASIC_SERVICE_TCP_DTCPCONTROL_H_
#define _ROOM_BASIC_SERVICE_TCP_DTCPCONTROL_H_

#include "common/etDatatypesCpp.hpp"


using namespace etRuntime; // TODO JH remove


class DTcpControl {

public:

	/*--------------------- attributes ---------------------*/
	 charPtr IPAddr;
	 int32 TcpPort;

	/* --------------------- attribute setters and getters */
	void setIPAddr(charPtr IPAddr) {
		 this->IPAddr = IPAddr;
	}
	charPtr getIPAddr() const {
		return this->IPAddr;
	}
	void setTcpPort(int32 TcpPort) {
		 this->TcpPort = TcpPort;
	}
	int32 getTcpPort() const {
		return this->TcpPort;
	}

	/*--------------------- operations ---------------------*/

	// default constructor, copy constructor and assignment operator
	DTcpControl();
	DTcpControl(const DTcpControl& rhs);
	DTcpControl& operator=(const DTcpControl& rhs);

	// constructor using fields
	// TODO
	//DTcpControl(charPtr IPAddr, int32 TcpPort);
};


#endif /* _ROOM_BASIC_SERVICE_TCP_DTCPCONTROL_H_ */

