package PingPongModel;

import org.eclipse.etrice.runtime.java.messaging.*;
import org.eclipse.etrice.runtime.java.modelbase.*;
import org.eclipse.etrice.runtime.java.debugging.*;

import static org.eclipse.etrice.runtime.java.etunit.EtUnit.*;

import room.basic.service.timing.*;
import room.basic.service.timing.PTimer.*;
import PingPongModel.PingPongProtocol.*;



public class Receiver extends ActorClassBase {


	//--------------------- ports
	protected PingPongProtocolPort recvPort = null;

	//--------------------- saps
	protected PTimerConjPort timingService = null;

	//--------------------- services

	//--------------------- optional actors

	//--------------------- interface item IDs
	public static final int IFITEM_recvPort = 1;
	public static final int IFITEM_timingService = 2;

	/*--------------------- attributes ---------------------*/

	/*--------------------- operations ---------------------*/


	//--------------------- construction
	public Receiver(IRTObject parent, String name) {
		super(parent, name);
		setClassName("Receiver");

		// initialize attributes

		// own ports
		recvPort = new PingPongProtocolPort(this, "recvPort", IFITEM_recvPort);

		// own saps
		timingService = new PTimerConjPort(this, "timingService", IFITEM_timingService, 0);

		// own service implementations

		// sub actors

		// wiring


		/* user defined constructor body */

	}

	/* --------------------- attribute setters and getters */


	//--------------------- port getters
	public PingPongProtocolPort getRecvPort (){
		return this.recvPort;
	}
	public PTimerConjPort getTimingService (){
		return this.timingService;
	}

	//--------------------- lifecycle functions
	public void stop(){
		super.stop();
	}

	public void destroy(){
		/* user defined destructor body */
		DebuggingService.getInstance().addMessageActorDestroy(this);
		super.destroy();
	}

	/* state IDs */
	public static final int STATE_waitingForPing = 2;
	public static final int STATE_receivedPing = 3;
	public static final int STATE_sentPong = 4;
	public static final int STATE_MAX = 5;
	
	/* transition chains */
	public static final int CHAIN_TRANS_INITIAL_TO__waitingForPing = 1;
	public static final int CHAIN_TRANS_tr0_FROM_waitingForPing_TO_receivedPing_BY_pingrecvPort = 2;
	public static final int CHAIN_TRANS_tr1_FROM_receivedPing_TO_sentPong_BY_timeouttimingService = 3;
	
	/* triggers */
	public static final int POLLING = 0;
	public static final int TRIG_recvPort__ping = IFITEM_recvPort + EVT_SHIFT*PingPongProtocol.IN_ping;
	public static final int TRIG_timingService__timeout = IFITEM_timingService + EVT_SHIFT*PTimer.OUT_timeout;
	public static final int TRIG_timingService__internalTimer = IFITEM_timingService + EVT_SHIFT*PTimer.OUT_internalTimer;
	public static final int TRIG_timingService__internalTimeout = IFITEM_timingService + EVT_SHIFT*PTimer.OUT_internalTimeout;
	
	// state names
	protected static final String stateStrings[] = {
		"<no state>",
		"<top>",
		"waitingForPing",
		"receivedPing",
		"sentPong"
	};
	
	// history
	protected int history[] = {NO_STATE, NO_STATE, NO_STATE, NO_STATE, NO_STATE};
	
	private void setState(int new_state) {
		DebuggingService.getInstance().addActorState(this,stateStrings[new_state]);
		this.state = new_state;
	}
	
	/* Entry and Exit Codes */
	protected void entry_receivedPing() {
		timingService.startTimeout(500);
	}
	protected void entry_sentPong() {
		recvPort.pong();
	}
	
	/* Action Codes */
	
	/* State Switch Methods */
	/**
	 * calls exit codes while exiting from the current state to one of its
	 * parent states while remembering the history
	 * @param current__et - the current state
	 * @param to - the final parent state
	 */
	private void exitTo(int current__et, int to) {
		while (current__et!=to) {
			switch (current__et) {
				case STATE_waitingForPing:
					this.history[STATE_TOP] = STATE_waitingForPing;
					current__et = STATE_TOP;
					break;
				case STATE_receivedPing:
					this.history[STATE_TOP] = STATE_receivedPing;
					current__et = STATE_TOP;
					break;
				case STATE_sentPong:
					this.history[STATE_TOP] = STATE_sentPong;
					current__et = STATE_TOP;
					break;
				default:
					/* should not occur */
					break;
			}
		}
	}
	
	/**
	 * calls action, entry and exit codes along a transition chain. The generic data are cast to typed data
	 * matching the trigger of this chain. The ID of the final state is returned
	 * @param chain__et - the chain ID
	 * @param generic_data__et - the generic data pointer
	 * @return the +/- ID of the final state either with a positive sign, that indicates to execute the state's entry code, or a negative sign vice versa
	 */
	private int executeTransitionChain(int chain__et, InterfaceItemBase ifitem, Object generic_data__et) {
		switch (chain__et) {
			case Receiver.CHAIN_TRANS_INITIAL_TO__waitingForPing:
			{
				return STATE_waitingForPing;
			}
			case Receiver.CHAIN_TRANS_tr0_FROM_waitingForPing_TO_receivedPing_BY_pingrecvPort:
			{
				return STATE_receivedPing;
			}
			case Receiver.CHAIN_TRANS_tr1_FROM_receivedPing_TO_sentPong_BY_timeouttimingService:
			{
				return STATE_sentPong;
			}
				default:
					/* should not occur */
					break;
		}
		return NO_STATE;
	}
	
	/**
	 * calls entry codes while entering a state's history. The ID of the final leaf state is returned
	 * @param state__et - the state which is entered
	 * @return - the ID of the final leaf state
	 */
	private int enterHistory(int state__et) {
		boolean skip_entry__et = false;
		if (state__et >= STATE_MAX) {
			state__et =  (state__et - STATE_MAX);
			skip_entry__et = true;
		}
		while (true) {
			switch (state__et) {
				case STATE_waitingForPing:
					/* in leaf state: return state id */
					return STATE_waitingForPing;
				case STATE_receivedPing:
					if (!(skip_entry__et)) entry_receivedPing();
					/* in leaf state: return state id */
					return STATE_receivedPing;
				case STATE_sentPong:
					if (!(skip_entry__et)) entry_sentPong();
					/* in leaf state: return state id */
					return STATE_sentPong;
				case STATE_TOP:
					state__et = this.history[STATE_TOP];
					break;
				default:
					/* should not occur */
					break;
			}
			skip_entry__et = false;
		}
		/* return NO_STATE; // required by CDT but detected as unreachable by JDT because of while (true) */
	}
	
	public void executeInitTransition() {
		int chain__et = Receiver.CHAIN_TRANS_INITIAL_TO__waitingForPing;
		int next__et = executeTransitionChain(chain__et, null, null);
		next__et = enterHistory(next__et);
		setState(next__et);
	}
	
	/* receiveEvent contains the main implementation of the FSM */
	public void receiveEventInternal(InterfaceItemBase ifitem, int localId, int evt, Object generic_data__et) {
		int trigger__et = localId + EVT_SHIFT*evt;
		int chain__et = NOT_CAUGHT;
		int catching_state__et = NO_STATE;
	
		if (!handleSystemEvent(ifitem, evt, generic_data__et)) {
			switch (getState()) {
			    case STATE_waitingForPing:
			        switch(trigger__et) {
			                case TRIG_recvPort__ping:
			                    {
			                        chain__et = Receiver.CHAIN_TRANS_tr0_FROM_waitingForPing_TO_receivedPing_BY_pingrecvPort;
			                        catching_state__et = STATE_TOP;
			                    }
			                break;
			                default:
			                    /* should not occur */
			                    break;
			        }
			        break;
			    case STATE_receivedPing:
			        switch(trigger__et) {
			                case TRIG_timingService__timeout:
			                    {
			                        chain__et = Receiver.CHAIN_TRANS_tr1_FROM_receivedPing_TO_sentPong_BY_timeouttimingService;
			                        catching_state__et = STATE_TOP;
			                    }
			                break;
			                default:
			                    /* should not occur */
			                    break;
			        }
			        break;
			    case STATE_sentPong:
			        break;
			    default:
			        /* should not occur */
			        break;
			}
		}
		if (chain__et != NOT_CAUGHT) {
			exitTo(getState(), catching_state__et);
			{
				int next__et = executeTransitionChain(chain__et, ifitem, generic_data__et);
				next__et = enterHistory(next__et);
				setState(next__et);
			}
		}
	}
	public void receiveEvent(InterfaceItemBase ifitem, int evt, Object generic_data__et) {
		int localId = (ifitem==null)? 0 : ifitem.getLocalId();
		receiveEventInternal(ifitem, localId, evt, generic_data__et);
	}

};
