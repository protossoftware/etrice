package TrafficLight_Model;

import org.eclipse.etrice.runtime.java.messaging.*;
import org.eclipse.etrice.runtime.java.modelbase.*;
import org.eclipse.etrice.runtime.java.debugging.*;

import static org.eclipse.etrice.runtime.java.etunit.EtUnit.*;

import room.basic.service.tcp.*;
import room.basic.service.timing.*;
import room.basic.service.tcp.PTcpControl.*;
import room.basic.service.tcp.PTcpPayload.*;
import room.basic.service.timing.PTimer.*;
import TrafficLight_Model.PTrafficLight.*;



public class TrafficlightExampleApplication extends ActorClassBase {

	
	//--------------------- ports
	
	//--------------------- saps
	
	//--------------------- services
	
	//--------------------- optional actors
	
	//--------------------- interface item IDs
	
	/*--------------------- attributes ---------------------*/
	/*--------------------- operations ---------------------*/

	//--------------------- construction
	public TrafficlightExampleApplication(IRTObject parent, String name) {
		super(parent, name);
		setClassName("TrafficlightExampleApplication");
		
		// initialize attributes

		// own ports
		
		// own saps
		
		// own service implementations
		
		// sub actors
		DebuggingService.getInstance().addMessageActorCreate(this, "light1");
		new TrafficLight(this, "light1");
		DebuggingService.getInstance().addMessageActorCreate(this, "light2");
		new TrafficLight(this, "light2");
		DebuggingService.getInstance().addMessageActorCreate(this, "controller");
		new TrafficController(this, "controller");
		DebuggingService.getInstance().addMessageActorCreate(this, "pedestrianLight");
		new PedestrianLight(this, "pedestrianLight");
		
		// wiring
		InterfaceItemBase.connect(this, "controller/light1", "light1/controller");
		InterfaceItemBase.connect(this, "controller/light2", "light2/controller");
		

	}
	
	/* --------------------- attribute setters and getters */
	
	
	//--------------------- port getters

	//--------------------- lifecycle functions
	public void stop(){
		stopUser();
		super.stop();
	}
	
	public void destroy() {
		DebuggingService.getInstance().addMessageActorDestroy(this);
		super.destroy();
	}

	//--------------------- no state machine
	public void receiveEvent(InterfaceItemBase ifitem, int evt, Object data) {
		handleSystemEvent(ifitem, evt, data);
	}
	
	public void executeInitTransition() {}
};
