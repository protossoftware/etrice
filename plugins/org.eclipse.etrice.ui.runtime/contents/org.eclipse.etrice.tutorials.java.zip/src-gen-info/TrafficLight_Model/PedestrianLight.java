package TrafficLight_Model;

import org.eclipse.etrice.runtime.java.messaging.*;
import org.eclipse.etrice.runtime.java.modelbase.*;
import org.eclipse.etrice.runtime.java.debugging.*;

import static org.eclipse.etrice.runtime.java.etunit.EtUnit.*;

import room.basic.service.tcp.*;
import room.basic.service.timing.*;
import room.basic.service.tcp.PTcpControl.*;
import room.basic.service.tcp.PTcpPayload.*;
import room.basic.service.timing.PTimer.*;



public class PedestrianLight extends ActorClassBase {

	
	//--------------------- ports
	protected PTcpControlConjPort tcpCtrl = null;
	protected PTcpPayloadConjPort tcpPayload = null;
	
	//--------------------- saps
	protected PTimerConjPort timeout = null;
	
	//--------------------- services
	
	//--------------------- optional actors
	
	//--------------------- interface item IDs
	public static final int IFITEM_tcpCtrl = 1;
	public static final int IFITEM_tcpPayload = 2;
	public static final int IFITEM_timeout = 3;
	
	/*--------------------- attributes ---------------------*/
	DTcpControl ipConfig;
	/*--------------------- operations ---------------------*/
	public void sendString(String text) {
		
						DTcpPayload pl = new DTcpPayload();
						pl.setData(text.getBytes());
						tcpPayload.send(new DTcpPayload(1, text.length(), text.getBytes()));
	}

	//--------------------- construction
	public PedestrianLight(IRTObject parent, String name) {
		super(parent, name);
		setClassName("PedestrianLight");
		
		// initialize attributes
		this.setIpConfig(new DTcpControl());

		// own ports
		tcpCtrl = new PTcpControlConjPort(this, "tcpCtrl", IFITEM_tcpCtrl);
		tcpPayload = new PTcpPayloadConjPort(this, "tcpPayload", IFITEM_tcpPayload);
		
		// own saps
		timeout = new PTimerConjPort(this, "timeout", IFITEM_timeout, 0);
		
		// own service implementations
		
		// sub actors
		DebuggingService.getInstance().addMessageActorCreate(this, "socketClient");
		new ATcpClient(this, "socketClient");
		
		// wiring
		InterfaceItemBase.connect(this, "socketClient/ControlPort", "tcpCtrl");
		InterfaceItemBase.connect(this, "socketClient/PayloadPort", "tcpPayload");
		

	}
	
	/* --------------------- attribute setters and getters */
	public void setIpConfig (DTcpControl ipConfig) {
		 this.ipConfig = ipConfig;
	}
	public DTcpControl getIpConfig () {
		return this.ipConfig;
	}
	
	
	//--------------------- port getters
	public PTcpControlConjPort getTcpCtrl (){
		return this.tcpCtrl;
	}
	public PTcpPayloadConjPort getTcpPayload (){
		return this.tcpPayload;
	}
	public PTimerConjPort getTimeout (){
		return this.timeout;
	}

	//--------------------- lifecycle functions
	public void stop(){
		stopUser();
		super.stop();
	}
	
	public void destroy() {
		DebuggingService.getInstance().addMessageActorDestroy(this);
		super.destroy();
	}

	/* state IDs */
	public static final int STATE_Operational = 2;
	public static final int STATE_OpenSocket = 3;
	public static final int STATE_Operational_AllRed = 4;
	public static final int STATE_Operational_CarGreen = 5;
	public static final int STATE_Operational_CarYellow = 6;
	public static final int STATE_Operational_CarRed = 7;
	public static final int STATE_Operational_PedGreen = 8;
	public static final int STATE_MAX = 9;
	
	/* transition chains */
	public static final int CHAIN_Operational_TRANS_tr1_FROM_AllRed_TO_CarGreen_BY_timeouttimeout = 1;
	public static final int CHAIN_Operational_TRANS_tr2_FROM_CarGreen_TO_CarYellow_BY_receivetcpPayload = 2;
	public static final int CHAIN_Operational_TRANS_tr3_FROM_CarYellow_TO_CarRed_BY_timeouttimeout = 3;
	public static final int CHAIN_Operational_TRANS_tr4_FROM_CarRed_TO_PedGreen_BY_timeouttimeout = 4;
	public static final int CHAIN_Operational_TRANS_tr5_FROM_PedGreen_TO_AllRed_BY_timeouttimeout = 5;
	public static final int CHAIN_TRANS_INITIAL_TO__OpenSocket = 6;
	public static final int CHAIN_TRANS_tr0_FROM_OpenSocket_TO_Operational_tp0_BY_establishedtcpCtrl = 7;
	
	/* triggers */
	public static final int POLLING = 0;
	public static final int TRIG_tcpCtrl__established = IFITEM_tcpCtrl + EVT_SHIFT*PTcpControl.OUT_established;
	public static final int TRIG_tcpCtrl__error = IFITEM_tcpCtrl + EVT_SHIFT*PTcpControl.OUT_error;
	public static final int TRIG_tcpPayload__receive = IFITEM_tcpPayload + EVT_SHIFT*PTcpPayload.OUT_receive;
	public static final int TRIG_timeout__timeout = IFITEM_timeout + EVT_SHIFT*PTimer.OUT_timeout;
	public static final int TRIG_timeout__internalTimer = IFITEM_timeout + EVT_SHIFT*PTimer.OUT_internalTimer;
	public static final int TRIG_timeout__internalTimeout = IFITEM_timeout + EVT_SHIFT*PTimer.OUT_internalTimeout;
	
	// state names
	protected static final String stateStrings[] = {
		"<no state>",
		"<top>",
		"Operational",
		"OpenSocket",
		"Operational_AllRed",
		"Operational_CarGreen",
		"Operational_CarYellow",
		"Operational_CarRed",
		"Operational_PedGreen"
	};
		
	// history
	protected int history[] = {NO_STATE, NO_STATE, NO_STATE, NO_STATE, NO_STATE, NO_STATE, NO_STATE, NO_STATE, NO_STATE};
	
	private void setState(int new_state) {
		DebuggingService.getInstance().addActorState(this,stateStrings[new_state]);
		this.state = new_state;
	}
	
	/* Entry and Exit Codes */
	protected void entry_OpenSocket() {
		tcpCtrl.open(ipConfig);
	}
	protected void entry_Operational_AllRed() {
		sendString("pedLights=red\n");
		sendString("carLights=red\n");
		timeout.startTimeout(1000);
	}
	protected void entry_Operational_CarGreen() {
		sendString("carLights=green\n");
		timeout.startTimeout(3000);
	}
	protected void entry_Operational_CarYellow() {
		sendString("carLights=yellow\n");
		timeout.startTimeout(1000);
	}
	protected void entry_Operational_CarRed() {
		sendString("carLights=red\n");
		timeout.startTimeout(1000);
	}
	protected void entry_Operational_PedGreen() {
		sendString("pedLights=green\n");
		timeout.startTimeout(3000);
	}
	
	/* Action Codes */
	
	/**
	 * calls exit codes while exiting from the current state to one of its
	 * parent states while remembering the history
	 * @param current - the current state
	 * @param to - the final parent state
	 */
	private void exitTo(int current, int to) {
		while (current!=to) {
			switch (current) {
				case STATE_OpenSocket:
					this.history[STATE_TOP] = STATE_OpenSocket;
					current = STATE_TOP;
					break;
				case STATE_Operational:
					this.history[STATE_TOP] = STATE_Operational;
					current = STATE_TOP;
					break;
				case STATE_Operational_AllRed:
					this.history[STATE_Operational] = STATE_Operational_AllRed;
					current = STATE_Operational;
					break;
				case STATE_Operational_CarGreen:
					this.history[STATE_Operational] = STATE_Operational_CarGreen;
					current = STATE_Operational;
					break;
				case STATE_Operational_CarYellow:
					this.history[STATE_Operational] = STATE_Operational_CarYellow;
					current = STATE_Operational;
					break;
				case STATE_Operational_CarRed:
					this.history[STATE_Operational] = STATE_Operational_CarRed;
					current = STATE_Operational;
					break;
				case STATE_Operational_PedGreen:
					this.history[STATE_Operational] = STATE_Operational_PedGreen;
					current = STATE_Operational;
					break;
				default:
					/* should not occur */
					break;
			}
		}
	}
	
	/**
	 * calls action, entry and exit codes along a transition chain. The generic data are cast to typed data
	 * matching the trigger of this chain. The ID of the final state is returned
	 * @param chain - the chain ID
	 * @param generic_data - the generic data pointer
	 * @return the +/- ID of the final state either with a positive sign, that indicates to execute the state's entry code, or a negative sign vice versa
	 */
	private int executeTransitionChain(int chain, InterfaceItemBase ifitem, Object generic_data) {
		switch (chain) {
			case CHAIN_TRANS_INITIAL_TO__OpenSocket:
			{
				return STATE_OpenSocket;
			}
			case CHAIN_TRANS_tr0_FROM_OpenSocket_TO_Operational_tp0_BY_establishedtcpCtrl:
			{
				return STATE_Operational_AllRed;
			}
			case CHAIN_Operational_TRANS_tr1_FROM_AllRed_TO_CarGreen_BY_timeouttimeout:
			{
				return STATE_Operational_CarGreen;
			}
			case CHAIN_Operational_TRANS_tr2_FROM_CarGreen_TO_CarYellow_BY_receivetcpPayload:
			{
				DTcpPayload data = (DTcpPayload) generic_data;
				return STATE_Operational_CarYellow;
			}
			case CHAIN_Operational_TRANS_tr3_FROM_CarYellow_TO_CarRed_BY_timeouttimeout:
			{
				return STATE_Operational_CarRed;
			}
			case CHAIN_Operational_TRANS_tr4_FROM_CarRed_TO_PedGreen_BY_timeouttimeout:
			{
				return STATE_Operational_PedGreen;
			}
			case CHAIN_Operational_TRANS_tr5_FROM_PedGreen_TO_AllRed_BY_timeouttimeout:
			{
				return STATE_Operational_AllRed;
			}
				default:
					/* should not occur */
					break;
		}
		return NO_STATE;
	}
	
	/**
	 * calls entry codes while entering a state's history. The ID of the final leaf state is returned
	 * @param state - the state which is entered
	 * @return - the ID of the final leaf state
	 */
	private int enterHistory(int state) {
		boolean skip_entry = false;
		if (state >= STATE_MAX) {
			state =  (state - STATE_MAX);
			skip_entry = true;
		}
		while (true) {
			switch (state) {
				case STATE_OpenSocket:
					if (!(skip_entry)) entry_OpenSocket();
					/* in leaf state: return state id */
					return STATE_OpenSocket;
				case STATE_Operational:
					/* state has a sub graph */
					/* without init transition */
					state = this.history[STATE_Operational];
					break;
				case STATE_Operational_AllRed:
					if (!(skip_entry)) entry_Operational_AllRed();
					/* in leaf state: return state id */
					return STATE_Operational_AllRed;
				case STATE_Operational_CarGreen:
					if (!(skip_entry)) entry_Operational_CarGreen();
					/* in leaf state: return state id */
					return STATE_Operational_CarGreen;
				case STATE_Operational_CarYellow:
					if (!(skip_entry)) entry_Operational_CarYellow();
					/* in leaf state: return state id */
					return STATE_Operational_CarYellow;
				case STATE_Operational_CarRed:
					if (!(skip_entry)) entry_Operational_CarRed();
					/* in leaf state: return state id */
					return STATE_Operational_CarRed;
				case STATE_Operational_PedGreen:
					if (!(skip_entry)) entry_Operational_PedGreen();
					/* in leaf state: return state id */
					return STATE_Operational_PedGreen;
				case STATE_TOP:
					state = this.history[STATE_TOP];
					break;
				default:
					/* should not occur */
					break;
			}
			skip_entry = false;
		}
		/* return NO_STATE; // required by CDT but detected as unreachable by JDT because of while (true) */
	}
	
	public void executeInitTransition() {
		int chain = CHAIN_TRANS_INITIAL_TO__OpenSocket;
		int next = executeTransitionChain(chain, null, null);
		next = enterHistory(next);
		setState(next);
	}
	
	/* receiveEvent contains the main implementation of the FSM */
	public void receiveEvent(InterfaceItemBase ifitem, int evt, Object generic_data) {
		int trigger = ifitem.getLocalId() + EVT_SHIFT*evt;
		int chain = NOT_CAUGHT;
		int catching_state = NO_STATE;
		
		if (!handleSystemEvent(ifitem, evt, generic_data)) {
			switch (getState()) {
				case STATE_OpenSocket:
					switch(trigger) {
							case TRIG_tcpCtrl__established:
								{
									chain = CHAIN_TRANS_tr0_FROM_OpenSocket_TO_Operational_tp0_BY_establishedtcpCtrl;
									catching_state = STATE_TOP;
								}
							break;
							default:
								/* should not occur */
								break;
					}
					break;
				case STATE_Operational_AllRed:
					switch(trigger) {
							case TRIG_timeout__timeout:
								{
									chain = CHAIN_Operational_TRANS_tr1_FROM_AllRed_TO_CarGreen_BY_timeouttimeout;
									catching_state = STATE_Operational;
								}
							break;
							default:
								/* should not occur */
								break;
					}
					break;
				case STATE_Operational_CarGreen:
					switch(trigger) {
							case TRIG_tcpPayload__receive:
								{
									chain = CHAIN_Operational_TRANS_tr2_FROM_CarGreen_TO_CarYellow_BY_receivetcpPayload;
									catching_state = STATE_Operational;
								}
							break;
							default:
								/* should not occur */
								break;
					}
					break;
				case STATE_Operational_CarYellow:
					switch(trigger) {
							case TRIG_timeout__timeout:
								{
									chain = CHAIN_Operational_TRANS_tr3_FROM_CarYellow_TO_CarRed_BY_timeouttimeout;
									catching_state = STATE_Operational;
								}
							break;
							default:
								/* should not occur */
								break;
					}
					break;
				case STATE_Operational_CarRed:
					switch(trigger) {
							case TRIG_timeout__timeout:
								{
									chain = CHAIN_Operational_TRANS_tr4_FROM_CarRed_TO_PedGreen_BY_timeouttimeout;
									catching_state = STATE_Operational;
								}
							break;
							default:
								/* should not occur */
								break;
					}
					break;
				case STATE_Operational_PedGreen:
					switch(trigger) {
							case TRIG_timeout__timeout:
								{
									chain = CHAIN_Operational_TRANS_tr5_FROM_PedGreen_TO_AllRed_BY_timeouttimeout;
									catching_state = STATE_Operational;
								}
							break;
							default:
								/* should not occur */
								break;
					}
					break;
				default:
					/* should not occur */
					break;
			}
		}
		if (chain != NOT_CAUGHT) {
			exitTo(getState(), catching_state);
			{
				int next = executeTransitionChain(chain, ifitem, generic_data);
				next = enterHistory(next);
				setState(next);
			}
		}
	}
};
