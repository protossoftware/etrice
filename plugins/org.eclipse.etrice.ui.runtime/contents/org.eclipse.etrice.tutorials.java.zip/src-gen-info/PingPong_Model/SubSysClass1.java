package PingPong_Model;

import org.eclipse.etrice.runtime.java.config.IVariableService;
import org.eclipse.etrice.runtime.java.messaging.IRTObject;
import org.eclipse.etrice.runtime.java.messaging.MessageService;
import org.eclipse.etrice.runtime.java.messaging.MessageServiceController;
import org.eclipse.etrice.runtime.java.messaging.RTServices;
import org.eclipse.etrice.runtime.java.modelbase.ActorClassBase;
import org.eclipse.etrice.runtime.java.modelbase.SubSystemClassBase;
import org.eclipse.etrice.runtime.java.modelbase.InterfaceItemBase;

import room.basic.service.timing.*;


public class SubSysClass1 extends SubSystemClassBase {
	
	public final int THREAD__DEFAULT = 0;
	public final int THREAD_DEFAULTTHREAD = 1;

	
	public SubSysClass1(IRTObject parent, String name) {
		super(parent, name);
	}
	
	@Override
	public void receiveEvent(InterfaceItemBase ifitem, int evt, Object data){
	}
	
	@Override	
	public void instantiateMessageServices() {
	
		RTServices.getInstance().getMsgSvcCtrl().addMsgSvc(new MessageService(this, 0, THREAD__DEFAULT, "MessageService_Main"));
		RTServices.getInstance().getMsgSvcCtrl().addMsgSvc(new MessageService(this, 0, THREAD_DEFAULTTHREAD, "MessageService_defaultThread" /*, thread_prio */));
	}

	@Override
	public void instantiateActors() {
		
		MessageServiceController msgSvcCtrl = RTServices.getInstance().getMsgSvcCtrl();

		// thread mappings
		msgSvcCtrl.addPathToThread("/LogSys1/subSysRef1", THREAD__DEFAULT);
		
		// port to peer port mappings
		msgSvcCtrl.addPathToPeers("/LogSys1/subSysRef1/actorRef1/sender/receiver", "/LogSys1/subSysRef1/actorRef1/receiver/sender");
		msgSvcCtrl.addPathToPeers("/LogSys1/subSysRef1/actorRef1/receiver/sender", "/LogSys1/subSysRef1/actorRef1/sender/receiver");
		msgSvcCtrl.addPathToPeers("/LogSys1/subSysRef1/actorRef1/receiver/timing", "/LogSys1/subSysRef1/timingService/timer");
		msgSvcCtrl.addPathToPeers("/LogSys1/subSysRef1/timingService/timer", "/LogSys1/subSysRef1/actorRef1/receiver/timing");

		// sub actors
		new PingPongTop(this, "actorRef1"); 
		new ATimingService(this, "timingService"); 
		
		// apply instance attribute configurations
	}
	
	@Override
	public void init(){
		super.init();
	}
		
	@Override
	public void stop(){
		super.stop();
	}
		
};
