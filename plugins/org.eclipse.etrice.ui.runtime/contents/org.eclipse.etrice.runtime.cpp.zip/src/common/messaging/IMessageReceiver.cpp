/*
 * IMessageReceiver.cpp
 *
 *  Created on: 08.06.2012
 *      Author: karlitsc
 */

#include "IMessageReceiver.h"

namespace etRuntime {

IMessageReceiver::IMessageReceiver() {
}

IMessageReceiver::~IMessageReceiver() {
}

} /* namespace etRuntime */
