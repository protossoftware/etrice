/*
 * IRTObject.cpp
 *
 *  Created on: 22.08.2012
 *      Author: karlitsc
 */


#include "IRTObject.h"

namespace etRuntime {

const std::string IRTObject::NO_NAME = "<no name>";

}

