/*
 * EventReceiver.cpp
 *
 *  Created on: 29.08.2012
 *      Author: karlitsc
 */

#include "EventReceiver.h"

namespace etRuntime {


EventReceiver::~EventReceiver() {
}

} /* namespace etRuntime */
