/*
 * IEventReceiver.cpp
 *
 *  Created on: 08.06.2012
 *      Author: karlitsc
 */

#include "IEventReceiver.h"

namespace etRuntime {

IEventReceiver::IEventReceiver() {
}

IEventReceiver::~IEventReceiver() {
}

} /* namespace etRuntime */
