/*
 * TestSemaphore.cpp
 *
 *  Created on: 31.08.2012
 *      Author: karlitsc
 */

#include "TestSemaphore.h"

namespace etRuntime {


TestSemaphore::~TestSemaphore() {
}

} /* namespace etRuntime */
